var http = require("http");
var express = require("express");
var mongodb = require("mongodb");
var body_parser = require("body-parser");
var mongoclient = mongodb.MongoClient;
var mongo_uri = process.env.MONGOHQ_URI ||
                process.env.MONGOHQ_URL ||
                "mongodb://heroku:ir2kepaEJNkNPJdltf4MzGnm2hEblp2bVjK_CKWi9nKmRALi9ZyNEbO3nPKimoZ7A8AC5bcvwjhize7yfSe_iw@dogen.mongohq.com:10091/app31155063";
var app = express();
app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));

var geocoderProvider = "google";
var httpAdapter = 'https';
var geooptions = {
    apiKey: 'AIzaSyB_OylcGFnQ-Ar8y5BA6hCcqdfIpW1gAaY'
};
var geocoder = require('node-geocoder').getGeocoder(geocoderProvider,
                                                    httpAdapter, geooptions);

/*  Enables Cross-Origin Resource Sharing
 */
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

/*  Reverse-geolocates user, puts info into database, responds with
 *  the last 100 entries.
 */
app.post("/sendLocation", function(request, response) {
    var login = request.body["login"];
    var lat = request.body["lat"];
    var lng = request.body["lng"];
    if (login && lat && lng) {
        geocoder.reverse(lat, lng, function(err, res) {
            var location_string = "";
            if (err || !res) {
                location_string += "Unknown";
            } else {
                var x = res[0];
                if (x.streetName) location_string += x.streetName;
                if (x.city) {
                    if (location_string != "") location_string += ", ";
                    location_string += x.city;  
                }
                if (x.stateCode) {
                    if (location_string != "") location_string += ", ";
                    location_string += x.stateCode;
                } 
                if (x.zipcode) {
                    if (location_string != "") {
                        if (x.stateCode) location_string += " ";
                        else             location_string += ", ";
                    }
                    location_string += x.zipcode;
                }    
                if (x.country) {
                    if (location_string != "") location_string += ", ";
                    location_string += x.country;
                }
            }
            var object = {"login": login,
                          "lat": lat,
                          "lng": lng,
                          "location": location_string,
                          "created_at": new Date().toString()};
            collection.insert(object, function(err, result) {
                if (err) {
                    response.status(500).end();
                    return
                }
                collection.find({}).sort({_id:-1}).limit(100)
                          .toArray(function(err, result) {
                    if (err) {
                        response.status(500).end();
                        return;
                    }
                    response.status(200);
                    response.send({"characters":[], "students":result});
                });
            });   
        });

    } else {
        response.status(400).end();
    }
});

/*  Finds all checkins for given login
 */
app.get("/locations.json", function(request, response) {
    var login = request.query["login"];
    if (login) {
        collection.find({"login":login}).sort({_id:-1})
                  .toArray(function(err, result) {
            if (err) {
                response.status(500).end();
                return;
            }
            response.status(200);
            response.send(result);
        });
    } else {
        response.status(200).send([]);
    }
});

/*  Gets redline info from the MBTA and sends it back
 */
app.get("/redline.json", function(request, response) {
    http.get("http://developer.mbta.com/lib/rthr/red.json", function(data) {
        response.status(data.statusCode);
        var chunks = [];
        data.on("data", function(chunk) {
            chunks.push(chunk);
        }).on("end", function() {
            var result = Buffer.concat(chunks).toString();
            response.send(JSON.parse(result));
        });
    }).on("error", function(err) {
        response.status(500).end();
    });
});

/*  Creates an HTML file based on info in the database
 */
app.get("/", function(request, response) {
    var html = "<!DOCTYPE html><html><head>";
    html += "<link rel='stylesheet' type='text/css' href='index.css'>";
    html += "<title>All Marauder Check-ins</title>";
    html += "</head><body><h1>All Check-ins:</h1>";
    collection.find().sort({_id:-1}).toArray(function(err, result) {
        if (err) {
            html += "<p>Error when fetching data: " + err + "</p>";
        } else {
            html += "<table>";
            html += "<tr><th>Name</th><th>Latitude</th><th>Longitude</th>";
            html += "<th>Address</th><th>Check-in time</th></tr>";
            var i = 0;
            for (var i in result) {
                var current = result[i];
                html += "<tr>";
                html += "<td>" + current.login + "</td>";
                html += "<td>" + Number(current.lat).toFixed(4) + "</td>";
                html += "<td>" + Number(current.lng).toFixed(4) + "</td>";
                html += "<td>" + current.location + "</td>";
                html += "<td>" + current.created_at + "</td>";
                html += "</tr>";
            };
            html += "</table></body></html>";
            response.status(200);
            response.send(html);
        }
    });
});

/*  For the root file's CSS
 */
app.get("/index.css", function(request, response) {
    response.sendFile("./index.css", {root: __dirname});
});

/*  Connects the database and the server
 */
mongoclient.connect(mongo_uri, function(err, database) {
    if (err) {
        return;
    }
    database.collection("locations", function(err, cln) {
        if (err) {
            return;
        }
        collection = cln;
        server = app.listen(process.env.PORT || 5000, function() {
            var host = server.address().address;
            var port = server.address().port;
//            console.log("Listening at http://%s:%s", host, port);
        });
    });
});
